package main;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Inventario1 {
  public static void main(String[] args) {
      Scanner sc= new Scanner(System.in);
  
      System.out.print("\033[H\033[2J");
      System.out.flush();

      DecimalFormat df= new DecimalFormat("#.00");

      int opc=0, cantidad, cantidad_producto=0, opc_mod, codigo_mod, posicion_precio=-1, nombre_mod, posicion_nombre=-1, cantidad_mod, posicion_cantidad=-1, search_producto;
      double iva=0.16, precio_mod, bs=0;

      //Arreglos
      int[] code = new int[99];
      String[] nombre = new String[99];
      double[] precio_dolar = new double[99];
      int[] amount = new int[99];

      //Menu
      do{
      System.out.println("\t\t -Menu-\n");
      System.out.println("[1] Agregar producto");
      System.out.println("[2] Editar productos");
      System.out.println("[3] Ver producto");
      System.out.println("[4] Estadisticas");
      System.out.println("[5] Configuracion");
      System.out.println("[6] Salir\n");
      opc = sc.nextInt(); 

      switch(opc){

          case 1: 
          
          //Añandiendo al inventario
          System.out.print("\033[H\033[2J");
          System.out.flush();
          System.out.println("\t\t -Administrando inventario-\n");                
          System.out.print("Cantidad de productos: ");
          cantidad = sc.nextInt();
          
              for(int i=0; i<cantidad; i++){
                  System.out.print("\nCodigo del producto #"+(cantidad_producto+1)+": ");
                  code[cantidad_producto]= sc.nextInt();
                  

                  System.out.print("Nombre: ");
                  nombre[cantidad_producto]= sc.next();
              
                  System.out.print("Precio en dolares: ");
                  precio_dolar[cantidad_producto]= sc.nextDouble();
                  if(precio_dolar[cantidad_producto]!=0){

                  System.out.print("Cantidad: ");
                  amount[cantidad_producto]= sc.nextInt();
                  cantidad_producto++;
                  
                  System.out.print("\033[H\033[2J");
                  System.out.flush();}
                  
                  else{
                      System.out.print("Precio invalido, intente de nuevo.");}
              }
          break;    

          case 2:

          //Editando inventario
          System.out.print("\033[H\033[2J");
          System.out.flush();

          do{
              System.out.print("\t\t -Editando inventario- \n\n");
              System.out.println("Codigo  Nombre  Cantidad  Precio $  Precio IVA  Precio bs.");
                  for(int i=0; i<cantidad_producto; i++){
                      System.out.println("#"+code[i]+"    "+nombre[i]+"    "+amount[i]+"    "+precio_dolar[i]+"$    "+(df.format((precio_dolar[i]*iva)+precio_dolar[i])+"$    "+df.format(((precio_dolar[i]*iva)+precio_dolar[i])*bs)+"bs."));}
          
          
              System.out.println("\n\n\n\t\t-Modificar-\n[1] Codigo\n[2] Nombre\n[3] Precio\n[4] Cantidad\n[5] Salir\n");
              opc_mod= sc.nextInt();

          
              if(opc_mod==1){
                  System.out.print("\nCodigo del producto: ");
                  codigo_mod= sc.nextInt();
                  for(int i=0; i<code.length; i++){
                      if(code[i]==codigo_mod){
                          System.out.print("Ingrese nuevo codigo: ");
                          code[i]= sc.nextInt();
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                      }
                  }
              }

              if(opc_mod==2){
                  System.out.print("\nCodigo del producto: ");
                  nombre_mod= sc.nextInt();
              
                  for(int i=0; i<code.length; i++){
                      if(code[i]==nombre_mod){
                          posicion_nombre=i;
                          System.out.print("Ingrese nuevo nombre: ");
                          nombre[posicion_nombre]= sc.next();
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                      }
                  }
              }

              if(opc_mod==3){
                  System.out.print("\nCodigo del producto: ");
                  precio_mod= sc.nextDouble();
              
                  for(int i=0; i<code.length; i++){
                      if(code[i]==precio_mod){
                          posicion_precio=i;
                          System.out.print("Ingrese nuevo precio: ");
                          precio_dolar[posicion_precio]= sc.nextDouble();
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                      }
                  }
              }
              
              if(opc_mod==4){
                  System.out.print("\nCodigo del producto: ");
                  cantidad_mod= sc.nextInt();
              
                  for(int i=0; i<code.length; i++){
                      if(code[i]==cantidad_mod){
                          posicion_cantidad=i;
                          System.out.print("Ingrese nuevamente la cantidad: ");
                          amount[posicion_cantidad]= sc.nextInt();
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                      }
                  }
              }

              if(opc_mod>=6 || opc_mod==0){
                  System.out.println("Opcion Invalida, Intente de nuevo...\n\n\n");
              }
          }

          while(opc_mod!=5);
          System.out.print("\033[H\033[2J");
          System.out.flush();
          break;
               
      
          case 3:

          //Ver algun producto
          int opc3=0;
          System.out.print("\033[H\033[2J");
          System.out.flush();
          do{
              System.out.print("\t\t-Busqueda de productos-\n\n");
              System.out.print("  Codigo\tNombre\tCantidad\n\n");
              for(int i=0; i<cantidad_producto; i++){
                  System.out.print("--> "+code[i]+"#\t"+nombre[i]+"\t"+amount[i]+"\n");
              }
              System.out.print("\n\nIngrese codigo del producto: ");
              search_producto= sc.nextInt();
              System.out.print("\033[H\033[2J");
              System.out.flush();
              System.out.print("Productos encontrados:\n\nCodigo\tNombre\tCantidad\tPrecio $\tPrecio Bs. + IVA\n");
              
                      for(int i=0; i<code.length; i++){
                          if(code[i]==search_producto){
                              System.out.print("#"+code[i]+"\t"+nombre[i]+"\t"+amount[i]+"\t\t"+df.format(precio_dolar[i])+"$\t\t"+df.format((((precio_dolar[i]*iva)+precio_dolar[i])*bs))+"bs.");
                              System.out.print("\n\nNueva busqueda? Y=1 N=0\n\n");
                              opc3= sc.nextInt();
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                          }
                      }
              }

              while(opc3!=0);
              System.out.print("\033[H\033[2J");
              System.out.flush();
              break;
          
          case 4:
          int total_producto=0, opc5, posicion_precio_mayor=0, posicion_precio_menor=0, producto0=0, posicion0=0, almacen=0, total_almacen=0;
          double mayor_precio=0;
          System.out.print("\033[H\033[2J");
          System.out.flush();

          do{
              System.out.print("\t\t-Estadisticas-\n\n");
              System.out.print("[1] Total de productos\n[2] Producto mas caro\n[3] Producto mas barato\n[4] Producto 0\n[5] Total bruto/neto\n[6] Total del inventario\n[7] Salir\n\n");
              opc5= sc.nextInt();
          
              if(opc5==1){
                  int w;
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  for(int i=0; i<code.length; i++){
                      if(code[i]>1){
                          total_producto++;
                      }
                  }

                  System.out.print("Hay "+total_producto+" productos en el inventario.\n\n[1] Salir\n\n");
                  w= sc.nextInt();
                  
                  while(w!=1);
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }

              if(opc5==2){
                  int w;
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  for(int i=0; i<cantidad_producto; i++){
                      if(precio_dolar[i]>mayor_precio){
                          mayor_precio=precio_dolar[i];
                          posicion_precio_mayor=i;
                      }
                  }

                  System.out.print(code[posicion_precio_mayor]+"# "+nombre[posicion_precio_mayor]+" "+amount[posicion_precio_mayor]+" unidad/es "+df.format(precio_dolar[posicion_precio_mayor])+"$ ");
                  System.out.print("\n\n[1] Salir\n\n");
                  w= sc.nextInt();

                  while(w!=1);
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }

              if(opc5==3){
                  int w;
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  for(int i=0; i<cantidad_producto; i++){
                      if(precio_dolar[i]<mayor_precio){
                          posicion_precio_menor=i;
                      }
                  }

                  System.out.print(code[posicion_precio_menor]+"# "+nombre[posicion_precio_menor]+" "+amount[posicion_precio_menor]+" unidad/es "+df.format(precio_dolar[posicion_precio_menor])+"$ ");

                  System.out.print("\n\n[1] Salir\n\n");
                  w= sc.nextInt();

                  while(w!=1);
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }

              if(opc5==4){
                  int w;
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  for(int i=0; i<cantidad_producto; i++){
                      if(amount[i]==producto0){
                          posicion0=i;
                          System.out.print("No hay reservas de ["+code[posicion0]+"#  "+nombre[posicion0]+"]\n");   
                      }
                  }

                  System.out.print("\n\n[1] Salir\n\n");
                  w= sc.nextInt();

                  while(w!=1);
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }
              
              if(opc5==5){
                  int w, precio_bruto=0;
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  for(int i=0; i<cantidad_producto; i++){
                      precio_bruto+=precio_dolar[i]*amount[i];
                  }

                  System.out.print("Precio Bruto: "+ df.format(precio_bruto)+"$ ");
                  System.out.print("Precio Neto: "+ df.format(((precio_bruto*iva)+precio_bruto))+"$");

                  System.out.print("\n\n[1] Salir\n\n");
                  w= sc.nextInt();

                  while(w!=1);
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }

              if(opc5==6){
                  int w;
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  System.out.print("\t\t-Total del inventario-\n\n");
                  System.out.println("Codigo  Nombre  Cantidad  Precio $  Precio IVA  Precio bs.");
                      for(int i=0; i<cantidad_producto; i++){
                          System.out.println("#"+code[i]+"    "+nombre[i]+"    "+amount[i]+"    "+df.format(precio_dolar[i])+"$    "+df.format(((precio_dolar[i]*iva)+precio_dolar[i]))+"$    "+df.format((((precio_dolar[i]*iva)+precio_dolar[i])*bs))+"bs.");}
                      
                  System.out.print("\n\nCantidad de productos: "+cantidad_producto);
                  for(int i=0; i<cantidad_producto; i++){
                      almacen=amount[i];
                      total_almacen+=almacen;

                  }
                  System.out.print("\nTotal en Almacen: "+total_almacen);
                  System.out.print("\n\n[1] Salir\n\n");
                  w= sc.nextInt();

                  while(w!=1);
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }
                  
          }

          while(opc5!=7);
          System.out.print("\033[H\033[2J");
          System.out.flush();
          break;

          case 5:

          //Configuraciones del menú
          int opc4;
          double iva_ajustable=0;
          System.out.print("\033[H\033[2J");
          System.out.flush();

          do{
              System.out.print("\t\t-Configuracion-\n");
              System.out.println("[1] IVA\n[2] Tasa de Bs del dia\n[3] Salir\n");
              opc4= sc.nextInt();

          
              if(opc4==1){
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  System.out.print("Porcentaje del IVA: ");
                  iva_ajustable= sc.nextDouble();
                  if(iva_ajustable>0.16){
                      iva=(iva_ajustable/100);
                      System.out.print("\033[H\033[2J");
                      System.out.flush();
                  }

                  if(iva_ajustable<0.16){
                      iva=0;
                      iva=iva_ajustable;
                  }
              }
          
              if(opc4==2){
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  System.out.print("Tasa de Bs del dia: ");
                  bs= sc.nextDouble();
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
              }

              if(opc4==3){
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  break;
              }

              if(opc4>=4 || opc4==0){
                  System.out.print("Opcion Invalida, intente de nuevo.");
                  
              }
          }
           
          while(opc4!=3);
          System.out.print("\033[H\033[2J");
          System.out.flush();
          break;
      }
  }

  while(opc!=6);
  System.out.print("\033[H\033[2J");
  System.out.flush();
  System.out.print("Saliendo...\n\n");

  }
}