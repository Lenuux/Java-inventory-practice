package main;

public class Word {

	private String Palabra;
	private int Cantidad;
	
	public String getPalabra() {
		return Palabra;
	}
	public void setPalabra(String palabra) {
		Palabra = palabra;
	}
	public int getCantidad() {
		return Cantidad;
	}
	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}
	
	public Word(String palabra, int cantidad) {
		super();
		Palabra = palabra;
		Cantidad = cantidad;
	}
}
