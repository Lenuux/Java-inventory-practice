package main;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class String_File{
	public static void main(String[] args) throws IOException{
		
		Scanner scin= new Scanner(System.in);
		List<Word> list= new ArrayList<Word> ();
	
		//Manejo de Excepciones.
		try {
			
		//Asignando la dirección del archivo a leer.
		System.out.print("Introduce la dirección del Archivo: ");
		String address= scin.nextLine();
			
		Scanner sc;
		File file= new File(address);
		sc= new Scanner(file);
		
		//X cantidad de palabras a buscar.
		System.out.print("\n\nCantidad de palabras a buscar: ");
		String cantidad= scin.next();
		int cantidad_int=Integer.parseInt(cantidad);
			
		for (int i=0; i<cantidad_int; i++) {
			System.out.print("Palabra n°"+(i+1)+": ");
			String Palabra= scin.next();
				
			Word word= new Word (Palabra, 0);
			word.setPalabra(Palabra);
			list.add(word);
			}
			
			//Mejorar busqueda, eliminando espacios, signos. mayusculas y minusculas.
			  while (sc.hasNextLine()) {
			    String linea= sc.nextLine();
			    String[] palabras= linea.split(" ");
			    
			    for (String count: palabras) {
			      count = count.replaceAll("[., ?¿!¡]", "");
			      for (Word count2: list) {
			        if(count.equalsIgnoreCase(count2.getPalabra())){
			          count2.setCantidad(count2.getCantidad() + 1);
			        }
			      }
			    }
			  }
			  sc.close();
			  
			  System.out.println("\n");
			  
			  //Impresión de las palabras encontradas
			  for (Word count: list) {
			    System.out.print(count.getPalabra()+" se repite "+count.getCantidad()+" veces.\n");
			  }
			  
		//Asignando ruta del archivo estadisticas.
		System.out.print("\nIntroduce la dirección de destino del Archivo Estadistica: ");
		String CreateRoute= scin.next(); 
				
		//BufferedWriter para almacenar en buffer y/o crear, modificar el archivo estadisticas.
		File fileStats= new File(CreateRoute);
		BufferedWriter bw= new BufferedWriter(new FileWriter(fileStats));
	
		bw.write("\t\t-Resultados de la busqueda-\n\n");
			for (Word count: list) {
				bw.write(count.getPalabra()+" se repite "+count.getCantidad()+" veces.\n");
			}
		
		bw.close();
		
		//Abriendo el archivo directamente con java.awt.Desktop
		Desktop dt= Desktop.getDesktop();
		dt.open(fileStats);
		scin.close(); 
			  
		}
		
		catch (FileNotFoundException e) {
            System.out.print("Archivo no Encontrado");
            System.exit(0);
        }
		
		
	}
}
