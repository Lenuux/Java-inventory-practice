package Main;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Herencia.Historial;
import Herencia.Persona;
import Herencia.Usuario;

public class Main {

public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		List<Persona> list= new ArrayList<Persona> ();
		List<Historial> historylist= new ArrayList<Historial>();
		Metodo methods= new Metodo();
		
		int MenuPrincipal;
		
		do {
			System.out.print("\n\t\t-BIENVENIDO A JOTAOCHIONPAIN-\n\n");
			System.out.print("(1) Registrar\n(2) Iniciar Sesion\n(3) Salir\n\n");
			MenuPrincipal= sc.nextInt();
			
			switch(MenuPrincipal) {
			
				case 1:
					methods.RegistrarUsuario(list);
					break;
					
				case 2:
					methods.IniciarSesion(list, historylist);
					break;
			}
		}
		
		while(MenuPrincipal!=3);
		System.out.print("\nSaliendo...");	
	}
}
