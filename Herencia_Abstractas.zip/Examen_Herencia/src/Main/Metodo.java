package Main;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import Herencia.Historial;
import Herencia.Operador;
import Herencia.Persona;
import Herencia.Usuario;


public class Metodo {
	Scanner sc= new Scanner(System.in);
	double bs= 34.4;

	/**
	* Metodo para Registro de Usuario/Operador
	* @param Usuario
	* @param Contraseña
	* @param Nombre
	* @param Telefono
	* @param Cedula
	* @param Operador
	*/	
	public void RegistrarUsuario(List<Persona> list) {
		Metodo ms= new Metodo();
		System.out.print("\t\t-Sing Up-\n\n");
		
		System.out.print("Usuario: ");
			String Usuario= sc.next();
			
			if(ms.UsuarioRepetido(Usuario, list)==true) {
				System.out.print("Contraseña: ");
					String Clave= sc.next();
				System.out.print("Nombre: ");
					String Nombre= sc.next();
				System.out.print("Telefono: ");
					String Telefono= sc.next();
				System.out.print("Cedula o RIF: ");
					String Cedula= sc.next();
				if(ms.CedulaRepetida(Cedula, list)==true) {
				System.out.print("Operador Y=1 N=0  ");
					int Operador= sc.nextInt();
					
				if(Operador==1) {
					Operador operador= new Operador (Usuario, Clave, Nombre, Telefono, Cedula, Operador);
					operador.setUsuario(Usuario);
					operador.setContraseña(Clave);
					operador.setNombre(Nombre);
					operador.setTelefono(Telefono);
					operador.setCedula(Cedula);
					operador.setOperador(Operador);
					
					list.add(operador);
				}
				
				if(Operador==0) {
					Usuario user= new Usuario (Usuario, Clave, Nombre, Telefono, Cedula, Operador);
					user.setUsuario(Usuario);
					user.setContraseña(Clave);
					user.setNombre(Nombre);
					user.setTelefono(Telefono);
					user.setCedula(Cedula);
					
					list.add(user);
				}
			}
			else {System.err.print("Cedula ya registrada.");}
		}
		else {System.err.println("Usuario ya registrado.\n");}
	}
	
	/**
	* Metodo para Inicio de Sesion
	* @param Usuario
	* @param Contraseña
	* @param Nombre
	* @param Telefono
	* @param Cedula
	*/
	public void IniciarSesion(List<Persona> list, List<Historial> historylist) {
		
		Metodo ms= new Metodo();
		System.out.print("\t\t-Login-\n\n");
		System.out.print("Usuario: ");
			String Usuario= sc.next();
		System.out.print("Contraseña: ");
			String Clave= sc.next();
		boolean match= false;
		Persona persona= null;
		
			for(Persona count:list) {
				if(Usuario.equals(count.getUsuario()) && Clave.equals(count.getContraseña())) {

					match=true;
					persona = count;
					if (persona instanceof Operador) {
						ms.MenuOperador(list, persona, historylist);
					}  
					
					if (persona instanceof Usuario) {
						ms.MenuUsuario(list, persona, historylist);
					}
					break;}
				else {continue;}
			}
			
			if(!match) {
					System.err.print("Usuario y/o Contraseña Erronea.");
			}
	}
	
	/**
	* Metodo para Menu de Operador
	* @param persona 
	* @param Usuario
	* @param Contraseña
	*/
	public void MenuOperador(List<Persona> list, Persona persona, List<Historial> historylist) {
		Metodo ms= new Metodo();
		int MenuOperador;
		do {
			System.out.print("\n\n\t\t-Menu Operador-\n\n");
			System.out.print("(1) Ver datos\n"
					+ 		 "(2) Modificar datos\n"
					+ 		 "(3) Lista de Usuarios\n"
					+ 		 "(4) Buscar Usuario\n"
					+		 "(5) Ver Transacciones\n"
					+ 		 "(6) Estadisticas\n"
					+ 		 "(7) Cerrar Sesion\n\n");
				MenuOperador= sc.nextInt();
			
				switch(MenuOperador) {
					case 1:
						ms.VerDatos(list, persona);
						break;
					case 2:
						ms.EditarDatos(list, persona);	
						break;
					case 3:
						ms.ListaUsuario(list);
						break;
					case 4:
						ms.BuscarUsuario(list);
						break;
					case 5:
						ms.Transacciones(list, historylist, persona);
						break;
					case 6:
						ms.Estadisticas(list, historylist);
						break;
				}
		}
				while(MenuOperador!=7);
				System.out.print("\nSaliendo...");
	}
	
	/**
	* Metodo para Menu de Usuario
	* @param persona 
	* @param Usuario
	* @param Contraseña
	*/
	public void MenuUsuario (List<Persona> list, Persona persona, List<Historial> historylist) {
		Metodo ms= new Metodo();
		int MenuUsuario;
		
		do {
		System.out.print("\t\t-Menu de Usuario-\n\n");
		System.out.print("(1) Ver datos"+"\t\t\t\tSaldo: "+((Usuario) persona).getSaldo()+"$ - "+(((Usuario) persona).getSaldo()*bs)+"bs. \n"
				+ 		 "(2) Modificar datos\n"
				+ 		 "(3) Transferir\n"
				+ 		 "(4) Depositar\n"
				+ 		 "(5) Retirar\n"
				+ 		 "(6) Cerrar Sesion\n\n");
			MenuUsuario= sc.nextInt();
				
		switch(MenuUsuario) {
			case 1:
				ms.VerDatos(list, persona);
				break;
				
			case 2:
				ms.EditarDatos(list, persona);
					break;
			case 3:
				ms.Transferencia(list, persona, historylist);
				break;
				
			case 4:
				ms.Deposito(list, persona, null, historylist);
				break;
				
			case 5:
				ms.Retiro(list, persona, null, historylist);
				break;
					
		}	
	}
		while(MenuUsuario!=6);
			System.out.print("\nSaliendo...");
	}
	
	/**
	* Metodo para Transferir
	 */
	public void Transferencia (List<Persona> list, Persona persona, List<Historial> historylist) {
		Persona Usuario= persona;
		System.out.print("\t\t-Transferencia-\n\n");
		System.out.print("Su Saldo: "+((Herencia.Usuario) Usuario).getSaldo());		
		System.out.print("\n\t\tDestinatario-\n");
		System.out.print("Telefono: ");
			String TelefonoT= sc.next();
		System.out.print("\nCedula: ");
			String CedulaT= sc.next();
		System.out.print("\nMonto a Transferir: ");
			double MontoT= sc.nextDouble();
		boolean match=false;
		Persona receptor = null;
		
		for(Persona count:list) {
			if(count.getTelefono().equals(TelefonoT)&&count.getCedula().equals(CedulaT)) {
				match=true;
				receptor=count;
				if(((Herencia.Usuario) persona).getSaldo()>=MontoT) {
				double SaldoNuevo= ((Herencia.Usuario) count).getSaldo()+MontoT;
				((Herencia.Usuario) count).setSaldo(SaldoNuevo);
				double SaldoRestante= ((Herencia.Usuario) persona).getSaldo()-MontoT;
				((Herencia.Usuario) persona).getSaldo();
				((Herencia.Usuario) persona).setSaldo(SaldoRestante);	
				}
				
				else {
					System.err.println("Saldo Insuficiente...");
				}
			}
		}
		if(!match) {System.err.println("Destinatario invalido...");}
	
		if(match==true) {
			Historial history= new Historial (Usuario.getUsuario(), Usuario.getNombre(),Usuario.getCedula(), null, MontoT, CedulaT);
			history.setUsuario(Usuario.getCedula());
			history.setNombre(Usuario.getNombre());
			history.setCedula(Usuario.getCedula());
			history.setTipo("Transferencia");
			history.setMonto(MontoT);
			history.setCedulaDestino(CedulaT);
			historylist.add(history);
			
			Historial historyReceptor= new Historial (receptor.getUsuario(), receptor.getNombre(),receptor.getCedula(), null, MontoT, Usuario.getCedula()); // historial del receptor
			historyReceptor.setUsuario(receptor.getCedula());
			historyReceptor.setNombre(receptor.getNombre());
			historyReceptor.setCedula(receptor.getCedula());
			historyReceptor.setTipo("Transferencia recibida");
			historyReceptor.setMonto(MontoT);
			historyReceptor.setCedulaDestino(Usuario.getCedula());
			historylist.add(historyReceptor);
		}
	}
	
	/**
	* Metodo para Deposito
	 */
	public void Deposito (List<Persona> list, Persona persona, Usuario usuario, List<Historial> historylist) {
		Persona Usuario= persona;
		System.out.print("\t\t-Deposito-\n\n");
		System.out.print("Su Saldo: "+((Herencia.Usuario) Usuario).getSaldo());
		System.out.print("\nIngrese monto: ");
			double Deposito= sc.nextDouble();
			
		((Herencia.Usuario) persona).getSaldo();
		((Herencia.Usuario) persona).setSaldo(Deposito);
		
		Historial history= new Historial (Usuario.getUsuario(), Usuario.getNombre(), Usuario.getCedula(), null, Deposito, null);
		history.setUsuario(Usuario.getUsuario());
		history.setNombre(Usuario.getNombre());
		history.setCedula(Usuario.getCedula());
		history.setTipo("Deposito");
		history.setMonto(Deposito);
		historylist.add(history);
	}
	
	/**
	* Metodo para Retiro
	 * @param list
	 * @param persona
	 * @param usuario
	 */
	public void Retiro (List<Persona> list, Persona persona, Usuario usuario, List<Historial> historylist) {
		Persona Usuario= persona;
		System.out.print("\t\t-Retiro-\n\n");
		System.out.print("Su saldo es: "+((Herencia.Usuario) Usuario).getSaldo());
		System.out.println("\nIngrese monto a retirar: ");
			double Retiro= sc.nextDouble();
		
		if(Retiro<=((Herencia.Usuario) Usuario).getSaldo()) {
			double Retiro1=((Herencia.Usuario) Usuario).getSaldo()-Retiro;
			((Herencia.Usuario) Usuario).setSaldo(Retiro1);
			
			Historial history= new Historial (Usuario.getUsuario(), Usuario.getNombre(), Usuario.getCedula(), null, Retiro, null);
			history.setUsuario(Usuario.getUsuario());
			history.setNombre(Usuario.getNombre());
			history.setCedula(Usuario.getCedula());
			history.setTipo("Retiro");
			history.setMonto(Retiro);
			historylist.add(history);
		}
		else {System.err.println("Error, Monto insuficiente...");}
	}
	
	/**
	 * Metodo para Leer Datos del Usuario
	 * @param list
	 * @param persona
	 */
	public void VerDatos (List<Persona> list, Persona persona) {
		System.out.print("\t\t-Datos de Usuario-\n\n");
		System.out.print("Cedula: "+persona.getCedula()
						+"\nUsuario: "+persona.getUsuario()
						+"\nNombre: "+persona.getNombre()
						+"\nTelefono: "+persona.getTelefono()+"\n\n");
	}

	/**
	 * Metodo para Editar Datos del Usuario
	 * @param list
	 * @param persona
	 */
	public void EditarDatos (List<Persona> list, Persona persona) {
		System.out.print("\t\t-Modificando Datos-\n\n");
		System.out.print("¿Que desea modificar?");
		System.out.print("\n(1) Cedula"
						+"\n(2) Usuario"
						+"\n(3) Contraseña"
						+"\n(4) Nombre"
						+"\n(5) Telefono"
						+"\n(6) Salir\n\n");
			int ModDatos= sc.nextInt();
		
			if(ModDatos==1) {
				System.out.print("Ingrese nueva Cedula: ");
						String NewCedula = sc.next();
				persona.getCedula();
				persona.setCedula(NewCedula);
			}
			
			if(ModDatos==2) {
				System.out.print("Ingrese nueva Usuario: ");
						String NewUsuario = sc.next();
				persona.getUsuario();
				persona.setUsuario(NewUsuario);
			}
			
			if(ModDatos==3) {
				System.out.print("Ingrese nueva Contraseña: ");
						String NewClave = sc.next();
				persona.getContraseña();
				persona.setContraseña(NewClave);
			}
					
			if(ModDatos==4) {
				System.out.print("Ingrese nuevo Nombre: ");
						String NewNombre = sc.next();
				persona.getNombre();
				persona.setNombre(NewNombre);
			}
			
			if(ModDatos==5) {
				System.out.print("Ingrese nuevo Telefono: ");
						String NewTelefono = sc.next();
				persona.getTelefono();
				persona.setTelefono(NewTelefono);
			}
			
			while(ModDatos!=6) {
				break;
			}
	}

	/**
	 * Metodo para Lista de Usuarios
	 * @param list
	 */
	public void ListaUsuario (List<Persona> list) {
		int i=0;
		Persona persona=null;
		for(Persona count:list) {
			persona=count;
			if(persona instanceof Usuario ) {
				System.out.print("\n("+i+")"+"\nNombre: "+count.getNombre()
										  +"\nCedula: "+count.getCedula());
				i++;
			}
		}
	}
	
	/**
	 * Metodo para Buscar Usuarios
	 * @param list
	 */
	public void BuscarUsuario (List<Persona> list) {
		Metodo ms= new Metodo();
		
		ms.ListaUsuario(list);
		System.out.print("\n\n\t\t-Busqueda de Usuario-\n\n ");
		System.out.print("Ingrese Cedula: ");
			String CedulaBuscar= sc.next();
		System.out.println("Ingrese Usuario: ");
			String UsuarioBuscar= sc.next();
			
			for(Persona count:list) {
				if(count.getCedula().equals(CedulaBuscar)&&count.getUsuario().equals(UsuarioBuscar)){
					System.out.println("Cedula: "+count.getCedula()
									 +"\nUsuario: "+count.getUsuario()
									 +"\nNombre: "+count.getNombre()
									 +"\nTelefono: "+count.getTelefono()+"\n\n");
				}
			}
	}
	
	/**
	 * Metodo para Listado de Transacciones
	 * @param list
	 * @param historylist
	 */
	public void Transacciones (List<Persona> list, List<Historial> historylist, Persona persona) {
		for(Historial count: historylist) {
			System.out.print("\nNombre: "+count.getNombre()
							+"\nCedula: "+count.getCedula()
							+"\nMonto: "+count.getMonto()
							+"\nTipo de Transaccion: ");
			System.out.print("\n---------------------------------------------");
		}
	}
	
	/**
	 * Metodo para las Estadisticas
	 * @param list
	 * @param historylist
	 */
	public void Estadisticas (List<Persona> list, List<Historial> historylist) {
		int DepositoCount = 0, RetiroCount=0, TransferenciaCount=0;
		System.out.print("\t\t-Estadisticas-\n\n");
		System.out.print("(1) Cantidad de Transacciones\n"
						+"(2) Usuario con Mayor/Menor Saldo\n");
			int EstadisticaMenu= sc.nextInt();
		
		if(EstadisticaMenu==1) {
			for (Historial count : historylist) {
				if(count.getTipo().equals("Deposito")) {
					DepositoCount++;
				}
				
				if(count.getTipo().equals("Retiro")) {
					RetiroCount++;
				}
				
				if(count.getTipo().equals("Transferencia")) {
					TransferenciaCount++;
				}
			}
			
			System.out.println("\nCantidad de Transferencia: "+TransferenciaCount
							  +"\nCantidad de Depositos: "+DepositoCount
							  +"\nCantidad de Retiros: "+RetiroCount);
		}
		
		if(EstadisticaMenu==2) {
			double maxSaldo = Double.NEGATIVE_INFINITY;
			double minSaldo = Double.POSITIVE_INFINITY;
			
			for (Persona usuario : list) {
			    if (usuario instanceof Usuario) {
			        double saldoActual = ((Usuario) usuario).getSaldo();
			        maxSaldo = Math.max(maxSaldo, saldoActual);
			        minSaldo = Math.min(minSaldo, saldoActual);
			    }
			}
			
			for(Persona usuario: list) {
				if (usuario instanceof Usuario) {
					if(((Usuario) usuario).getSaldo()==maxSaldo) {
						System.out.println("Usuario: "+usuario.getNombre()+  "\nCon mayor saldo: " + maxSaldo+"\n");
					}
				}
			}
			System.out.print("\n-----------------------\n");
			
			for(Persona usuario: list) {
				if (usuario instanceof Usuario) {
					if(((Usuario) usuario).getSaldo()==minSaldo) {
						System.out.println("Usuario: "+usuario.getNombre()+ "\nCon menor saldo: " + minSaldo+"\n");
					}
				}
			}
		}	
	}
	
	/**
	 * Función para Usuario Repetido
	 * @param Usuario
	 * @param list
	 * @return
	 */
	public boolean UsuarioRepetido (String Usuario, List<Persona> list) {
		for(Persona count:list) {
			if(Usuario.equals(count.getUsuario())) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Función para Cedula Repetida
	 * @param Cedula
	 * @param list
	 * @return
	 */
	public boolean CedulaRepetida (String Cedula, List<Persona> list) {
		for(Persona count:list) {
			if(Cedula.equals(count.getCedula())) {
				return false;
			}
		}
		return true;
	}
}
