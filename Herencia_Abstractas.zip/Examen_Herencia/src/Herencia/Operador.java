package Herencia;

public class Operador extends Persona{
	
	/**
	 * @param Usuario - Heredada
	 * @param Contraseña - Heredada
	 * @param Nombre - Heredada
	 * @param Telefono - Heredada
	 * @param Cedula - Heredada
	 * @param Operador (Permisos de Administrador)
	 */

	//Atributos
	private int Operador;
	
	//Constructor
	public Operador(String Usuario, String Clave, String Nombre, String Telefono, String Cedula, int Operador) {
		super(Usuario, Clave, Nombre, Telefono, Cedula);
		this.Operador= Operador;
		}

	//Setters y Getters
	public int getOperador() {
		return Operador;
	}
	public void setOperador(int operador) {
		Operador = operador;
	}
}