package Herencia;

public class Persona {

	/**
	 * @param Usuario
	 * @param Contraseña
	 * @param Nombre
	 * @param Telefono
	 * @param Cedula
	 */
	
	//Atributos
	private String Usuario; //No se puede REPETIR
	private String Clave;
	private String Nombre;
	private String Telefono;
	private String Cedula; //No se puede REPETIR
	
	//Constructor
	public Persona (String Usuario, String Clave, String Nombre, String Telefono, String Cedula) {
		this.Usuario= Usuario;
		this.Clave= Clave;
		this.Nombre= Nombre;
		this.Telefono= Telefono;
		this.Cedula= Cedula;
	}
	
	//Getters y Setters
	public String getUsuario() {
		return Usuario;
	}
	public void setUsuario(String usuario) {
		Usuario = usuario;
	}
	public String getContraseña() {
		return Clave;
	}
	public void setContraseña(String clave) {
		Clave = clave;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getTelefono() {
		return Telefono;
	}
	public void setTelefono(String telefono) {
		Telefono = telefono;
	}
	public String getCedula() {
		return Cedula;
	}
	public void setCedula(String cedula) {
		Cedula = cedula;
	}
}

