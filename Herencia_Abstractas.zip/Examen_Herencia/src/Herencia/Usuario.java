package Herencia;

public class Usuario extends Persona {
	private double Saldo;
	/**
	 * @param Usuario - Heredada
	 * @param Contraseña - Heredada
	 * @param Nombre - Heredada
	 * @param Telefono - Heredada
	 * @param Cedula - Heredada
	 * @param Saldo
	 */

	
	//Constructor
	public Usuario(String Usuario, String Clave, String Nombre, String Telefono, String Cedula, double Saldo) {
		super(Usuario, Clave, Nombre, Telefono, Cedula);
		this.Saldo=Saldo;
	}
	public double getSaldo() {
		return Saldo;
	}
	public void setSaldo(double saldo) {
		Saldo = saldo;
	}
}