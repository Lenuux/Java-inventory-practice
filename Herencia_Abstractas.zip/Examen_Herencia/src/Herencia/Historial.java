package Herencia;

public class Historial extends Persona {

	private String Tipo;
	private double Monto;
	private String CedulaDestino;
	
	public Historial(String Usuario, String Nombre, String Cedula, String Tipo, double Monto, String CedulaDestino) {
		super(Usuario, Nombre, Cedula, null, null);
		this.Tipo=Tipo;
		this.Monto=Monto;
		this.CedulaDestino=CedulaDestino;
	}
	
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	public double getMonto() {
		return Monto;
	}
	public void setMonto(double monto) {
		Monto = monto;
	}
	public String getCedulaDestino() {
		return CedulaDestino;
	}
	public void setCedulaDestino(String cedulaDestino) {
		CedulaDestino = cedulaDestino;
	}
}