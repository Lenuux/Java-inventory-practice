/*
Ingresar X cantidad de personas e indicar:
	1.Persona más alta {Nombre y altura}
	2. Persona más baja {Nombre y altura}
	3. Persona más pesada {Nombre y peso}
	4. Persona menos pesada {Nombre y peso}
	5. Cantidad de personas
	6. Cantidad de hombres y mujeres
	7. Salir

Datos: Nombre, altura(metros), peso (kilo), sexo

Nota: 
Altura {pies, centímetros}
Peso {Libras}
 */

package RepasoCpp;
import java.util.Scanner;

	public class Array {
		
		public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.println("Ingrese cantidad de personas: ");
	        int cantidad= sc.nextInt();

	        double altura_min=10, altura_max=0, peso_max=0, peso_min=10, altura_c, altura_p, altura_cm, altura_pm, peso_l, peso_lm;
	        int hombre=0, mujer=0, salir;

	        double[] altura= new double[cantidad];
	        double[] peso= new double[cantidad];
	        int[] gender= new int[cantidad];
	        String[] Nombre= new String[cantidad];
	        
	        do{
	            for(int i=0; i<cantidad; i++){
	            System.out.println("Ingrese nombre "+ (i+1)+":");
	            Nombre[i]=sc.next();}

	            for(int i=0; i<cantidad; i++){
	            System.out.println("Ingrese altura en metros"+(i+1)+": ");
	            altura[i]= sc.nextDouble();
	            
	                if(altura[i]>altura_max){
	                altura_max=altura[i];}

	                if(altura[i]<altura_min){
	                altura_min=altura[i];}}
	            
	            altura_c=altura_max*100;
	            altura_p=altura_max*3.281;
	            altura_cm=altura_min*100;
	            altura_pm=altura_min*3.281;

	            for(int i=0; i<cantidad; i++){
	            System.out.println("Ingrese peso en kg "+(i+1)+": ");
	            peso[i]=sc.nextDouble();
	            
	                if(peso[i]>peso_max){
	                peso_max=peso[i];}
	            
	                if(peso[i]<peso_min){
	                peso_min=peso[i];}}

	            peso_l=peso_max*2.20462;
	            peso_lm=peso_min*2.20462;

	            for(int i=0; i<cantidad; i++){
	            System.out.println((i+1)+ " Es hombre(1) o mujer(2)?: ");
	            gender[i]=sc.nextInt();

	                if(gender[i]==1){
	                hombre++;}

	                else{mujer++;}}

	        System.out.print("\033[H\033[2J");
	        System.out.flush();

	        System.out.println("Persona mas alta: "+altura_c +"cm - "+ altura_p +"ft");
	        System.out.println("Persona mas baja: "+ altura_cm +"cm - "+ altura_pm +"ft");
	        System.out.println("Persona mas pesada: "+peso_l+"lb");
	        System.out.println("Persona menos pesada: "+peso_lm+"lb");
	        System.out.println("Cantidad de personas: "+cantidad);
	        System.out.println("Cantidad de hombres: "+hombre);
	        System.out.println("Cantidad de mujeres: "+mujer+"\n");
	        System.out.println("Continuar Y=1 N=0 ");
	        salir= sc.nextInt();
	    
	        System.out.print("\033[H\033[2J");
	        System.out.flush();}

	        while(salir!=0);
	        System.out.print("Saliendo...");
	    }
	    
	}
