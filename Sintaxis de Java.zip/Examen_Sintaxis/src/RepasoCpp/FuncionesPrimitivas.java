/*
Ingresar X cantidad de notas e indicar 
	1. Nota mas alta
	2. Nota más baja
	3. Promedio
	4. Cantidad  de notas
	5. Salir
 */

package RepasoCpp;
import java.util.Scanner;

public class FuncionesPrimitivas {
  public static void main(String[] args) { 
    Scanner sc= new Scanner(System.in);

    double nota_max = 0, nota_min = 10, promedio=0, suma_notas=0;
    int salir;

     System.out.println("Ingrese la cantidad de notas:"); 
     int  cantidad= sc.nextInt(); 

    double[] notas = new double[cantidad];

    do{
    
     for(int i=0; i<cantidad; i++) {

        System.out.println("Ingrese la nota numero " + (i+1) + ": ");
             notas[i] = sc.nextDouble();

             if (notas[i]>nota_max) { 
             nota_max = notas[i]; } 
             
             if (notas[i]<nota_min) { 
             nota_min = notas[i]; } }

          System.out.print("\033[H\033[2J");
          System.out.flush();

         System.out.println("La nota más alta es: " + nota_max); 
         System.out.println("La nota más baja es: " + nota_min);
        
        for(int i=0; i<cantidad; i++){
          suma_notas+=notas[i];}

          promedio=suma_notas/cantidad;
        
          System.out.println("El promedio es de: "+promedio);
          System.out.println("Cantidad de notas: "+cantidad+"\n");
        
          System.out.print("Continuar Y=1 N=0 ");
          salir=sc.nextInt();
        
          System.out.print("\033[H\033[2J");
          System.out.flush();}

    while(salir!=0);
          
            System.out.println("Saliendo...");
    }
}
