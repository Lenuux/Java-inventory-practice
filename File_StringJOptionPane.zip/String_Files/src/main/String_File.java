package main;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class String_File{
	public static void main(String[] args) throws IOException{
		
		List<Word> list= new ArrayList<Word> ();
	
		//Asignando la dirección del archivo a leer.
		String address= (String) JOptionPane.showInputDialog(null, "Introduce la dirección del Archivo", "Search File", JOptionPane.INFORMATION_MESSAGE);
		
		//Validación de address vacio,
		if(address == null) {
			JOptionPane.showMessageDialog(null, "Saliendo...", "Exit", JOptionPane.DEFAULT_OPTION);
			System.exit(0);
		}
		
		//Validación de address sin espacios.
		if(address.equals("") || address.trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Dirección Invalida.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		
		Scanner sc;
		File file= new File(address);
		
		//X cantidad de palabras a buscar.
		String cantidad= JOptionPane.showInputDialog(null, "Cantidad de palabras a buscar", "Search Word", JOptionPane.INFORMATION_MESSAGE);
		int cantidad_int= Integer.parseInt(cantidad);
		
		for (int i=0; i<cantidad_int; i++) {
			String Palabra= JOptionPane.showInputDialog(null, "Palabra n°"+(i+1), "Search Word", JOptionPane.DEFAULT_OPTION);
			
			Word word= new Word (Palabra, 0);
			word.setPalabra(Palabra);
			list.add(word);
		}
		
		//Manejo de Excepciones.
		try {
			sc= new Scanner(file);
			
			//Mejorar busqueda, eliminando espacios, signos. mayusculas y minusculas.
			  while (sc.hasNextLine()) {
			    String linea= sc.nextLine();
			    String[] palabras= linea.split(" ");
			    
			    for (String count: palabras) {
			      count = count.replaceAll("[., ?¿!¡]", "");
			      for (Word count2: list) {
			        if(count.equalsIgnoreCase(count2.getPalabra())){
			          count2.setCantidad(count2.getCantidad() + 1);
			        }
			      }
			    }
			  }
			  sc.close();
			  
			  //Impresión de las palabras encontradas
			  for (Word count: list) {
			    JOptionPane.showMessageDialog(null, count.getPalabra()+" se repite "+count.getCantidad()+" veces.");
			  }
		}
		
		catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Archivo no Encontrado", "File not found", JOptionPane.ERROR_MESSAGE);
        }
		
		//Asignando ruta del archivo estadisticas.
		String CreateRoute= (String) JOptionPane.showInputDialog(null, "Introduce la dirección de destino del Archivo Estadistica", "Create File", JOptionPane.INFORMATION_MESSAGE);
		
		//Mismas validaciones de la dirección.
		if(CreateRoute == null) {
			JOptionPane.showMessageDialog(null, "Saliendo...", "Exit", JOptionPane.DEFAULT_OPTION);
			System.exit(0);
		}
		
		if(CreateRoute.equals("") || address.trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Dirección Invalida.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		
		//BufferedWriter para almacenar en buffer y/o crear, modificar el archivo estadisticas.
		File fileStats= new File(CreateRoute);
		BufferedWriter bw= new BufferedWriter(new FileWriter(fileStats));
		
			bw.write("\t\t-Resultados de la busqueda-\n\n");
			for (Word count: list) {
				bw.write(count.getPalabra()+" se repite "+count.getCantidad()+" veces.\n");
			}
		
			bw.close();
		
		//Abriendo el archivo directamente con java.awt.Desktop.
		Desktop dt= Desktop.getDesktop();
		dt.open(fileStats);
	}
}
