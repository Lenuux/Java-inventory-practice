package Objecto;

public class Producto {

	
	private String Codigo;
	private String Nombre;
	private Double Precio;
	private Integer Descuento;
	private Integer Cantidad;
	
	public Producto (String Codigo, String Nombre, Double Precio, Integer Descuento, Integer Cantidad) {
		
		this.Codigo= Codigo;
		this.Nombre= Nombre;
		this.Precio= Precio;
		this.Descuento= Descuento;
		this.Cantidad= Cantidad;
	}

	public String getCodigo() {
		return Codigo;
	}

	public void setCodigo(String codigo) {
		Codigo = codigo;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public Double getPrecio() {
		return Precio;
	}

	public void setPrecio(Double precio) {
		Precio = precio;
	}

	public Integer getDescuento() {
		return Descuento;
	}

	public void setDescuento(Integer descuento) {
		Descuento = descuento;
	}

	public Integer getCantidad() {
		return Cantidad;
	}

	public void setCantidad(Integer cantidad) {
		Cantidad = cantidad;
	}
}
