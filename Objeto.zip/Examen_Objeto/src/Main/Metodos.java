package Main;
import java.util.List;
import java.util.Scanner;
import Objecto.Producto;

public class Metodos {

	Scanner sc= new Scanner(System.in);
	
	public void ProductoAgregar (List<Producto> list) {

		String Codigo = null, Nombre = null;
		double Precio = 0;
		int Descuento = 0,Cantidad = 0, CantidadProducto;
		
				
		 System.out.print("Cantidad de Producto: ");
		 CantidadProducto= sc.nextInt();
		 Metodos methods= new Metodos();
		 
		 for(int i=0; i<CantidadProducto; i++) {
			 
			 System.out.print("Codigo del Producto: ");
			 Codigo= sc.next();
			 
			 if(methods.CodigoRepetido(Codigo, list)==true) {
				 System.out.print("Nombre: ");
				 Nombre= sc.next();
			 
				 System.out.print("Precio$: ");
				 Precio= sc.nextDouble();
				 
				 if(methods.PrecioNegativo(Precio, list)==true) {
					System.out.print("Descuento%: ");
					Descuento= sc.nextInt();
					 
					System.out.print("Cantidad: ");
					Cantidad= sc.nextInt();
					System.out.print("\n");
					 
					Producto item= new Producto(Codigo, Nombre, Precio, Descuento, Cantidad);
					item.setCodigo(Codigo);
					item.setNombre(Nombre);
					item.setPrecio(Precio);
					item.setDescuento(Descuento);
					item.setCantidad(Cantidad);
					 
					list.add(item); 
				 }
				 else {
					 System.err.print("Precio Invalido.\n\n");
					 break;
				 }
			 }
			 else {
				 System.err.print("Codigo Invalido.\n\n");
				 break;
			 }
		 }
	}
	
	public void ProductoLista (List<Producto> list, double IVA, double bsTasa) {
		int i=0;
		System.out.print("#\tID\tNombre\tPrecio\tPrecioIVA  PrecioBs  Descuento%\n");

		 for(Producto count:list) {
			 System.out.print(i+"\t"+count.getCodigo()+"\t"+ count.getNombre()+"\t"+ count.getPrecio()+"\t"+((count.getPrecio()*IVA)+count.getPrecio())+"\t  "+(count.getPrecio()*bsTasa)+"bs.\t"+count.getDescuento()+"%\n");
			 i++;
		 }
	}
	
	public void ProductoEditar (List<Producto> list) {
		int index, EditMenu, DescuentoNuevo, CantidadNuevo;
		double PrecioNuevo;
		String CodigoNuevo, NombreNuevo;
		 
		 
		 
		System.out.print("\nIngrese numero del producto a cambiar: ");
		index= sc.nextInt();
		 
		System.out.print("\n\n[Menu de Edicion]\n[1] Codigo\n[2] Nombre\n[3] Precio\n[4] Descuento\n[5] Cantidad\n");
		EditMenu= sc.nextInt();
		 
		if(EditMenu==1) {
			 
			System.out.print("Codigo Nuevo: ");
			CodigoNuevo= sc.next();
			list.get(index).getCodigo();
			list.get(index).setCodigo(CodigoNuevo);
		 }
		 
		if(EditMenu==2) {
			 
			System.out.print("Nombre Nuevo: ");
			NombreNuevo= sc.next();
			list.get(index).getNombre();
			list.get(index).setNombre(NombreNuevo);
		 }
		 
		if(EditMenu==3) {
			 
			System.out.print("Precio Nuevo: ");
			PrecioNuevo= sc.nextDouble();
		 	list.get(index).getPrecio();
		 	list.get(index).setPrecio(PrecioNuevo);
		 }
		
		if(EditMenu==4) {
			 
			System.out.print("Descuento Nuevo: ");
			DescuentoNuevo= sc.nextInt();
			list.get(index).getDescuento();
			list.get(index).setDescuento(DescuentoNuevo);
		}
		
		if(EditMenu==5) {
			 
			 System.out.print("Cantidad Nuevo: ");
			 CantidadNuevo= sc.nextInt();
			 list.get(index).getCantidad();
			 list.get(index).setCantidad(CantidadNuevo);
		}
	}
	
	public void ProductoBusqueda (List<Producto> list, double IVA) {
		System.out.print("\nIngrese numero del producto a buscar: ");
		int index = sc.nextInt();
		System.out.print("\n\nCodigo\tNombre\tPrecio$\tPrecioIVA\tDescuento%\tCantidad\n");
		
		System.out.print(list.get(index).getCodigo()+"\t"+list.get(index).getNombre()+"\t"+list.get(index).getPrecio()+"\t"+((list.get(index).getPrecio()*IVA)+list.get(index).getPrecio())+"\t"+list.get(index).getDescuento()+"\t\t"+list.get(index).getCantidad()+"\n\n");
	}
	
	public double ConfiguracionIVA (double IVA) {
		System.out.print("Ajuste del IVA\nIngrese nuevo valor:");
		double IVAModificado= sc.nextDouble();
		return IVAModificado;
	}
	
	public double ConfiguracionBsTasa (double BsTasa) {
		System.out.print("Ajuste de la Tasa de Bs.\nIngrese nuevo valor: ");
		double BsTasaModificado= sc.nextDouble();
		return BsTasaModificado;
	}
	
	public boolean CodigoRepetido (String Codigo, List<Producto> list) {
		for(Producto count:list) {
			if(Codigo.equals(count.getCodigo())) {
				return false;
			}
		}
		return true;
	}
	
	public boolean PrecioNegativo (double Precio, List<Producto> list) {
		for(Producto count:list) {
			if(Precio<=0) {
				return false;
			}
		}
		return true;
	}
}