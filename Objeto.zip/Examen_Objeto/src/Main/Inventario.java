package Main;

import java.util.Scanner;
import Objecto.Producto;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import Estadistica.Stats;

public class Inventario {

	
	public static void main(String[] args) {

		int opcSwitch = 0;
		double IVA=0.16, BsTasa = 0;
			 
		Scanner sc= new Scanner(System.in);
		List<Producto> list= new ArrayList<Producto> ();
		Metodos methods= new Metodos();
		Stats stats= new Stats();
		DecimalFormat df= new DecimalFormat("#.00");
		
		
			do { 
			 System.out.print("\t\t-Menu de Inventario-\n\n");
			 System.out.print("[1] Registrar\n[2] Editar\n[3] Listado de Productos\n[4] Estadisticas\n[5] Configuracion\n[6] Salir\n\n");
			 opcSwitch= sc.nextInt();
			 
			 switch(opcSwitch) {
			 
				 case 1:
					 System.out.print("\t\t-Registrar Producto/s-\n\n");
					 methods.ProductoAgregar(list);
					 break;
				
					 
				 case 2:
					 System.out.print("\t\t-Editar Producto/s-\n\n");
					 methods.ProductoLista(list, IVA, BsTasa);
					 methods.ProductoEditar(list);
					 break;
					 
				 case 3: 
					 System.out.print("\t\t-Listado de Producto/s-\n\n");
					 methods.ProductoLista(list, IVA, BsTasa);
					 methods.ProductoBusqueda(list, IVA);
					 break;
				 
				 case 4:
					 System.out.print("\t\t-Estadisticas-\n\n");
					 System.out.print("[1] Total Bruto/Neto\n[2] Cantidad de Productos\n[3] Producto mas/menos Costoso\n[4] Producto mas/menos Cantidad\n[5] Producto mas/menos Descuento\n[6] Total de Productos\n\n");
					 int opcStats= sc.nextInt();
					 
					 if(opcStats==1) {
						 stats.StatsTotal(list, IVA, BsTasa, df);
					 }
					 
					 if(opcStats==2) {
						 stats.StatsCantidad(list);
						 }
					 
					 if(opcStats==3) {
						 stats.StatsProductoCostoso(list, BsTasa, df);
					 }
					 
					 if(opcStats==4) {
						 stats.StatsProductoCantidad(list);
						 System.out.print("\n\n");
					 }
					 
					 if(opcStats==5) {
						 stats.StatsProductoDescuento(list);
					 }
					 
					 if(opcStats==6) {
						 stats.StatsTotalProducto(list);
					 }
					 
					 break;
					 
				 case 5:
					 System.out.print("\t\t-Configuracion-\n\n");
					 System.out.print("[1] IVA\n[2] Tasa del dia (bs.)\n\n");
					 int opcConfiguracion1= sc.nextInt();
					 
					 if(opcConfiguracion1==1) {
						IVA= methods.ConfiguracionIVA(IVA); 
						
					 }
					 
					 if(opcConfiguracion1==2) {
						BsTasa=methods.ConfiguracionBsTasa(BsTasa); 
					 }
					 break;
			 }		
		}
		
		while(opcSwitch!=6);
		System.out.print("Saliendo...");
		
		
		
		
	}
}
