package Estadistica;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import Main.Metodos;
import Objecto.Producto;

public class Stats {

	Metodos methods= new Metodos();
	Scanner sc= new Scanner(System.in);
	
	public void StatsTotal (List<Producto> List, double IVA, double bsTasa, DecimalFormat df) {
		double PrecioTotal=0, PrecioNeto=0;	
		for(Producto count:List) {
			PrecioTotal+=count.getPrecio()*count.getCantidad();
			PrecioNeto+=count.getPrecio()*count.getCantidad();
		}
		System.out.print("\nPrecio Bruto: "+PrecioTotal+"$ - "+ df.format(PrecioTotal*bsTasa)+"\nPrecio Neto: "+((PrecioNeto*IVA)+PrecioNeto)+"$ - "+df.format(((PrecioNeto*IVA)+PrecioNeto)*bsTasa)+"\n\n");
	}
	
	public void StatsCantidad (List<Producto> List) {
		int Amount = 0;
		for(Producto count:List) {
			Amount+= count.getCantidad();
		}
		System.out.print("\nCantidad de Productos en el Inventario: "+Amount+" unidad/es\n\n");
	}
	
	public void StatsProductoCostoso (List<Producto> List, double bsTasa, DecimalFormat df) {
		double PrecioMax= List.get(0).getPrecio();
		double PrecioMin= List.get(0).getPrecio();
		
		List<Producto> MayorPrecio= new ArrayList<>();
		List<Producto> MenorPrecio= new ArrayList<>();
		
		for(Producto count:List) {
			if(count.getPrecio()>PrecioMax) {
				PrecioMax= count.getPrecio();
				MayorPrecio.clear();
				MayorPrecio.add(count);
			}
			else if(count.getPrecio()==PrecioMax) {
				MayorPrecio.add(count);
			}
			
			if(count.getPrecio()<PrecioMin) {
				PrecioMin= count.getPrecio();
				MenorPrecio.clear();
				MenorPrecio.add(count);
			}
			else if(count.getPrecio()==PrecioMin) {
				MenorPrecio.add(count);
			}
		}
		System.out.print("Producto mas Caro: \n");
		for(Producto count:MayorPrecio) {
			System.out.print(count.getNombre()+"\n");
		}
		System.out.print("Precio: "+PrecioMax+"$ - "+df.format((PrecioMax*bsTasa))+"bs.");
		
		System.out.print("\n\nProducto mas Barato: \n");
		for(Producto count:MenorPrecio) {
			System.out.print(count.getNombre()+"\n");
		}
		System.out.print("Precio: "+PrecioMin+"$ - "+df.format((PrecioMin*bsTasa))+"bs.\n\n");
	}
	
	public void StatsProductoCantidad (List<Producto> List) {
		int CantidadMax= List.get(0).getCantidad();
		int CantidadMin= List.get(0).getCantidad();
		
		List<Producto> MayorCantidad= new ArrayList<>();
		List<Producto> MenorCantidad= new ArrayList<>();
		
		for(Producto count:List) {
			if(count.getCantidad()>CantidadMax) {
				CantidadMax=count.getCantidad();
				MayorCantidad.clear();
				MayorCantidad.add(count);
			}
			else if(count.getCantidad()==CantidadMax) {
				MayorCantidad.add(count);
			}
			
			if(count.getCantidad()<CantidadMin) {
				CantidadMin= count.getCantidad();
				MenorCantidad.clear();
				MenorCantidad.add(count);
			}
			else if(count.getCantidad()==CantidadMin) {
				MenorCantidad.add(count);
			}
		}
		System.out.print("Producto con Mayor Cantidad: \n");
		for(Producto count:MayorCantidad) {
			System.out.print(count.getNombre()+"\n");
		}
		System.out.print("Cantidad: "+CantidadMax+" unidad/es");
		
		System.out.print("\n\nProducto con Menor Cantidad: \n");
		for(Producto count:MenorCantidad) {
			System.out.print(count.getNombre()+"\n");
		}
		System.out.print("Cantidad: "+CantidadMin+" unidad/es");
	}
	
	public void StatsProductoDescuento (List<Producto> List) {
		int DescuentoMax= List.get(0).getDescuento();
		int DescuentoMin= List.get(0).getDescuento();
		
		List<Producto> MayorDescuento= new ArrayList<>();
		List<Producto> MenorDescuento= new ArrayList<>();
		
		for(Producto count:List) {
			if(count.getDescuento()>DescuentoMax) {
				DescuentoMax=count.getDescuento();
				MayorDescuento.clear();
				MayorDescuento.add(count);
			}
			else if(count.getDescuento()==DescuentoMax) {
				MayorDescuento.add(count);
			}
			
			if(count.getDescuento()<DescuentoMin) {
				DescuentoMin= count.getDescuento();
				MenorDescuento.clear();
				MenorDescuento.add(count);
			}
			else if(count.getDescuento()==DescuentoMin) {
				MenorDescuento.add(count);
			}
		}
		System.out.print("Producto con Mayor Descuento: \n");
		for(Producto count:MayorDescuento) {
			System.out.print(count.getNombre()+"\n");
		}
		System.out.print("Descuento: "+DescuentoMax+"%");
		
		System.out.print("\n\nProducto con Menor Descuento: \n");
		for(Producto count:MenorDescuento) {
			System.out.print(count.getNombre()+"\n");
		}
		System.out.print("Descuento: "+DescuentoMin+"%");
	}
	
	public void StatsTotalProducto (List<Producto> List) {
		int TotalProducto=0;
		for(Producto count:List) {
			TotalProducto+=count.getCantidad();
		}
		System.out.print("Productos en Almacen: "+TotalProducto+" unidad/es.\n\n");
	}
}
